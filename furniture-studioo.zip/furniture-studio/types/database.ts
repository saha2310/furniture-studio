// Типы таблиц Supabase. При изменении схемы (supabase/migrations) — обновить вручную,
// либо сгенерировать через `supabase gen types typescript` и заменить этот файл.

export type WorkStatus = 'draft' | 'published';

export interface Database {
  public: {
    Tables: {
      categories: {
        Row: {
          id: string;
          name: string;
          slug: string;
          sort_order: number;
          created_at: string;
          image_path: string | null;
          // Несжатый оригинал, из которого сделан image_path — нужен, чтобы
          // повторное кадрирование в редакторе стартовало от исходника, а не
          // от уже обрезанного результата (см. 0010_image_originals.sql).
          image_original_path: string | null;
        };
        Insert: {
          id?: string;
          name: string;
          slug: string;
          sort_order?: number;
          image_path?: string | null;
          image_original_path?: string | null;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['categories']['Insert']>;
      };
      works: {
        Row: {
          id: string;
          category_id: string;
          title: string;
          slug: string;
          description: string | null;
          price: string | null;
          specs: Record<string, string> | null;
          cover_image_id: string | null;
          is_featured: boolean;
          sort_order: number;
          status: WorkStatus;
          created_at: string;
          updated_at: string;
          // Цветовые варианты: все строки с одинаковым group_id — один товар
          // в разных цветах. is_primary отмечает вариант, который показывается
          // карточкой по умолчанию на /works.
          group_id: string;
          color_name: string | null;
          color_hex: string | null;
          is_primary: boolean;
        };
        Insert: {
          id?: string;
          category_id: string;
          title: string;
          slug: string;
          description?: string | null;
          price?: string | null;
          specs?: Record<string, string> | null;
          cover_image_id?: string | null;
          is_featured?: boolean;
          sort_order?: number;
          status?: WorkStatus;
          created_at?: string;
          updated_at?: string;
          // Не указывать при создании обычного товара без вариантов — БД
          // сама подставит group_id = id (см. миграцию 0006). Указывать
          // явно нужно только когда добавляем ещё один цвет к существующему
          // товару: group_id = group_id того товара, к которому добавляем.
          group_id?: string;
          color_name?: string | null;
          color_hex?: string | null;
          is_primary?: boolean;
        };
        Update: Partial<Database['public']['Tables']['works']['Insert']>;
      };
      work_images: {
        Row: {
          id: string;
          work_id: string;
          storage_path: string;
          original_path: string | null;
          catalog_position_x: number;
          catalog_position_y: number;
          catalog_zoom: number;
          catalog_flip_horizontal: boolean;
          alt_text: string | null;
          sort_order: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          work_id: string;
          storage_path: string;
          original_path?: string | null;
          catalog_position_x?: number;
          catalog_position_y?: number;
          catalog_zoom?: number;
          catalog_flip_horizontal?: boolean;
          alt_text?: string | null;
          sort_order?: number;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['work_images']['Insert']>;
      };
      // Дополнительные категории работы (см. 0007_work_categories.sql).
      // Основная категория по-прежнему хранится в works.category_id — здесь
      // только категории "вдобавок" к ней.
      work_categories: {
        Row: {
          work_id: string;
          category_id: string;
          created_at: string;
        };
        Insert: {
          work_id: string;
          category_id: string;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['work_categories']['Insert']>;
      };
      site_settings: {
        Row: {
          id: number;
          company_name: string | null;
          logo_path: string | null;
          logo_original_path: string | null;
          favicon_path: string | null;
          favicon_original_path: string | null;
          phone: string | null;
          email: string | null;
          address: string | null;
          seo_default_title: string | null;
          seo_default_description: string | null;
          og_image_path: string | null;
          og_image_original_path: string | null;
          updated_at: string;
        };
        Insert: Partial<Database['public']['Tables']['site_settings']['Row']> & { id?: number };
        Update: Partial<Database['public']['Tables']['site_settings']['Row']>;
      };
      contact_links: {
        Row: {
          id: string;
          platform: string;
          label: string;
          url: string;
          icon_key: string | null;
          is_visible: boolean;
          sort_order: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          platform: string;
          label: string;
          url: string;
          icon_key?: string | null;
          is_visible?: boolean;
          sort_order?: number;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['contact_links']['Insert']>;
      };
      home_sections: {
        Row: {
          id: string;
          key: string;
          title: string | null;
          subtitle: string | null;
          content_json: Record<string, unknown> | null;
          is_visible: boolean;
          sort_order: number;
          updated_at: string;
        };
        Insert: {
          id?: string;
          key: string;
          title?: string | null;
          subtitle?: string | null;
          content_json?: Record<string, unknown> | null;
          is_visible?: boolean;
          sort_order?: number;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['home_sections']['Insert']>;
      };
      site_menu_items: {
        Row: {
          id: string;
          label: string;
          href: string;
          sort_order: number;
          is_visible: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          label: string;
          href: string;
          sort_order?: number;
          is_visible?: boolean;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['site_menu_items']['Insert']>;
      };
      contact_requests: {
        Row: {
          id: string;
          name: string;
          contact: string;
          request_type: string | null;
          comment: string | null;
          status: 'new' | 'in_progress' | 'done';
          source_page: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          contact: string;
          request_type?: string | null;
          comment?: string | null;
          status?: 'new' | 'in_progress' | 'done';
          source_page?: string | null;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['contact_requests']['Insert']>;
      };
    };
  };
}
