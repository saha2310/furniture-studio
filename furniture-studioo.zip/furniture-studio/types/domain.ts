import type { Database } from './database';

export type Category = Database['public']['Tables']['categories']['Row'];
export type WorkRow = Database['public']['Tables']['works']['Row'];
export type WorkImage = Database['public']['Tables']['work_images']['Row'];
export type SiteSettings = Database['public']['Tables']['site_settings']['Row'];
export type ContactLink = Database['public']['Tables']['contact_links']['Row'];
export type HomeSectionRow = Database['public']['Tables']['home_sections']['Row'];

// Work вместе со связанными данными — то, что реально используется в UI.
export interface WorkWithRelations extends WorkRow {
  category: Category;
  images: WorkImage[];
  coverImage: WorkImage | null;
  // Id дополнительных категорий (см. work_categories / 0007_work_categories.sql),
  // без учёта основной category_id. Заполняется только там, где это реально
  // нужно (форма редактирования в админке) — на остальных выборках может
  // отсутствовать, поэтому необязательное поле.
  extraCategoryIds?: string[];
}

// Публичный URL строится из storage_path в lib/utils/image.ts.
export interface WorkImageWithUrl extends WorkImage {
  url: string;
}

export interface WorkWithUrls extends Omit<WorkWithRelations, 'images' | 'coverImage'> {
  images: WorkImageWithUrl[];
  coverImage: WorkImageWithUrl | null;
}

// Лёгкая карточка соседнего цветового варианта — то, что нужно для свотчей
// на /works и для переключателя цвета на странице товара. Не тянет полную
// галерею и specs соседа, только то, что нужно для превью.
export interface WorkColorVariant {
  id: string;
  slug: string;
  colorName: string | null;
  colorHex: string | null;
  isPrimary: boolean;
  coverImage: WorkImageWithUrl | null;
}

// Товар на /works вместе со списком цветовых вариантов той же группы
// (включая себя самого) — уже отсортирован так, что isPrimary всегда первый.
export interface WorkWithVariants extends WorkWithUrls {
  colorVariants: WorkColorVariant[];
}

// Известные ключи секций главной страницы. Каждая секция валидируется своей zod-схемой
// на основе этого ключа — см. lib/validations/home-section.schema.ts.
export type HomeSectionKey =
  | 'hero'
  | 'what_we_create'
  | 'featured_works'
  | 'process'
  | 'custom_made'
  | 'about_teaser'
  | 'contact_cta'
  | 'contacts_gallery';

export interface HeroContent {
  title: string;
  description: string;
  primaryCtaLabel: string;
  primaryCtaHref: string;
  secondaryCtaLabel: string;
  secondaryCtaHref: string;
  imagePath: string | null;
  // Несжатый оригинал Hero-картинки — см. imagePath. Хранится тут же, в
  // content_json, а не отдельной колонкой (как у site_settings/categories),
  // потому что вся секция и так гибкая jsonb-структура.
  imageOriginalPath: string | null;
}

export interface ProcessStep {
  title: string;
  description: string;
}

export interface ProcessContent {
  steps: ProcessStep[];
}

export const KNOWN_CONTACT_PLATFORMS = [
  'telegram',
  'whatsapp',
  'vk',
  'instagram',
  'tiktok',
  'youtube',
  'phone',
  'email',
  'custom',
] as const;

export type ContactPlatform = (typeof KNOWN_CONTACT_PLATFORMS)[number];
